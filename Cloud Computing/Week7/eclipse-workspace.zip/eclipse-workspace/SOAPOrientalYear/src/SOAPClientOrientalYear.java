import org.apache.axis.client.*;
import java.lang.Integer;
import java.net.*;
import java.io.BufferedReader; 
import java.io.InputStreamReader;

public class SOAPClientOrientalYear {	
	
	public static void main(String[] args) throws Exception {

      BufferedReader reader =  new BufferedReader(new InputStreamReader(System.in)); 

      String endpoint = "http://localhost:8080/axis/SOAPServerOrientalYear.jws";
      Service service = new Service();
      Call call = (Call)service.createCall();
      call.setTargetEndpointAddress(new URL(endpoint));
      
      System.out.println("Enter the year: ");
      String year = reader.readLine();
      System.out.println("Enter the language {en|it}: ");
      String lang = reader.readLine();

      Object[] params = new Object[]{Integer.valueOf(year), lang};

      String response = (String)call.invoke("getAnimal", params);
      
      System.out.println(year + "-year of the " + response);
   }
}