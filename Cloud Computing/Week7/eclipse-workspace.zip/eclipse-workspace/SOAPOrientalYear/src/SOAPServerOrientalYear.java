public class SOAPServerOrientalYear {

	static String[] en = {"Mouse", "Ox", "Tiger", 
			"Hare", "Dragon", "Snake", "Horse", "Sheep", 
			"Monkey", "Rooster", "Dog", "Pig"};
	static String[] it = {"Topo", "Bue", "Tigre", 
			"Lepre", "Drago", "Serpente", "Cavallo", "Pecora", 
			"Scimmia", "Gallo", "Cane", "Maiale"};
	
	public String getAnimal(int year, String lang) {
		int n = getYearNumber(year)-1;
		if (lang.equals("it")) {
			return it[n];
		}
		else {
			return en[n];
		} 
	}

	public int getYearNumber(int year) {
		int animal = (year+8) % 12;
		return animal+1;
	}
}

	