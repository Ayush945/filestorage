import org.apache.axis.client.*;
import java.lang.Integer;
import java.net.*;

public class StockQuoteClient {
   public static void main(String[] args) 
      throws Exception {
      String endpoint =
         "http://localhost:8080/axis/StockQuoteService.jws";
      Service service = new Service();
      Call call = (Call)service.createCall();
      call.setTargetEndpointAddress(new URL(endpoint));
      Object[] params = 
         new Object[]{String.valueOf(args[0])};
      Float response = (Float)call.invoke("getQuote",
         params);
      System.out.println(args[0]+ " quote is: " 
         +response);
      

   }
}
